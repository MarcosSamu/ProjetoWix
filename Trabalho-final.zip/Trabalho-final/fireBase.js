  var firebaseConfig = {
    apiKey: "AIzaSyDaIQfQdvWVzlGgtnPPM_AZXabaRen2uJk",
    authDomain: "projeto-final-763e5.firebaseapp.com",
    databaseURL: "https://projeto-final-763e5.firebaseio.com",
    projectId: "projeto-final-763e5",
    storageBucket: "",
    messagingSenderId: "44503922957",
    appId: "1:44503922957:web:cc3177b852c3408c"
  };
  firebase.initializeApp(firebaseConfig);
