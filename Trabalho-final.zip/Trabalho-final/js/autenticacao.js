// Buttons
var createUserButton = document.getElementById('createUserButton');

// Inputs
var nomeInput = document.getElementById('nomeInput')
var emailInput = document.getElementById('emailInput');
var passwordInput = document.getElementById('passwordInput');

// Criar novo usuário
createUserButton.addEventListener('click', function () {
    firebase
        .auth()
        .createUserWithEmailAndPassword(emailInput.value, passwordInput.value)
        .then(function () {
             alert('Cadastrado com sucesso ' + nomeInput.value),
             window.location.href="../Trabalho-final/login.html",             

        })
        .catch(function (error) {
            console.error(error.code);
            console.error(error.message);
            alert('Falha ao cadastrar, verifique o erro no console.')
        });
});

