var sair = document.getElementById('sair')



sair.addEventListener('click', function () {
    firebase
        .auth()
        .signOut()
        .then(function () {
            // displayName.innerText = 'Você não está autenticado';
            alert('Você se deslogou'),
            window.location.href="../Trabalho-final/login.html"
        }, function (error) {
            console.error(error);
        });
});