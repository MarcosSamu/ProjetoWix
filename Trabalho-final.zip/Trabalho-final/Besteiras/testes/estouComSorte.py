import random
lista = ['Samuel', 'Marcos', 'Cornelio']
print("O nome escolhido ", random.choice(lista))