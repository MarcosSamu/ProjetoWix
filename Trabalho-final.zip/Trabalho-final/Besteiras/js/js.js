function toggler(x) {
  x.classList.toggle("change");
} 
window.onload = function(){   
    $('#demo_3').t(
      {speed:80}
      
    )
}
